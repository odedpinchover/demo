public class consts {

    public static final String decimalFormat = "0.00";
    public static final String dateFormat = "dd/MM/yyyy";
    public static final String features = "features";
    public static final String properties = "properties";
    public static final String time = "time";
    public static final String magnitude = "mag";
    public static final String outputFileName = "output.txt";
    public static final String place = "place";


}
